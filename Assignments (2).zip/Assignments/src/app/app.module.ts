import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Assign1Component } from './assign1/assign1.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Assign2Component } from './assign2/assign2.component';
import { Assign3Component } from './assign3/assign3.component';
import { ComponentxComponent } from './assign3/componentx/componentx.component';
import { ComponentYComponent } from './assign3/componentx/component-y/component-y.component';
import { Assign4Component } from './assign4/assign4.component';
import { Comp1Component } from './assign4/comp1/comp1.component';
import { ShoppingListService } from './assign4/shopping-list.service';
import { Comp2Component } from './assign4/comp2/comp2.component';
import { Comp3Component } from './assign4/comp3/comp3.component';
import { Comp4Component } from './assign4/comp4/comp4.component';

const appRoutes: Routes =[  
  {path:'assign1', component:Assign1Component },
  {path:'assign2', component:Assign2Component },
  {path:'assign3', component:Assign3Component},
  {path:'assign4', component:Assign4Component }
]

@NgModule({
  declarations: [
    AppComponent,
    Assign1Component,
    Assign2Component,
    Assign3Component,
    ComponentxComponent,
    ComponentYComponent,
    Assign4Component,
    Comp1Component,
    Comp2Component,
    Comp3Component,
    Comp4Component
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ShoppingListService],
  bootstrap: [AppComponent]
})
export class AppModule { }
