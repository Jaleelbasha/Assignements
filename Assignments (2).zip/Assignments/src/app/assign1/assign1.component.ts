import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign1',
  templateUrl: './assign1.component.html',
  styleUrls: ['./assign1.component.css']
})
export class Assign1Component  {
  names='';
  set=false;
  allow=[
    2,3,10,15,26,35,50,63
  ]
  
  constructor() { }



  Add(){
  this.set= true;
  
  }


}
