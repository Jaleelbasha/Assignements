import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-assign2',
  templateUrl: './assign2.component.html',
  styleUrls: ['./assign2.component.css']
})
export class Assign2Component implements OnInit {
  signupForm: FormGroup;

  constructor() { }

  ngOnInit() {
    this.signupForm = new FormGroup({
      'phonenumber': new FormControl(),
      'phone': new FormArray([])
    })
    
  }

  onSubmit(){
    console.log(this.signupForm)
  }
  AddOn(){
    const control = new FormControl(null);
    (<FormArray>this.signupForm.get('phone')).push(control);
  }

}
