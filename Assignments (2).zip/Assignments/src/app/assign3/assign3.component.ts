import { Component, ComponentFactoryResolver, ComponentRef, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ComponentxComponent } from './componentx/componentx.component';

@Component({
  selector: 'app-assign3',
  templateUrl: './assign3.component.html',
  styleUrls: ['./assign3.component.css']
})
export class Assign3Component implements OnInit {
  @ViewChild('appenHere', {static : false, read : ViewContainerRef}) target: ViewContainerRef;
  private componentRef: ComponentRef<any>;

  constructor(private resolver: ComponentFactoryResolver) { }

  ngOnInit(){
  }
  addNewComponent() {
    let childComponent = this.resolver.resolveComponentFactory(ComponentxComponent);
    this.componentRef = this.target.createComponent(childComponent); // <-- here it's throws an error!
  }  

}
