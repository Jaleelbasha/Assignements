import { Component, ComponentFactoryResolver, ComponentRef, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ComponentYComponent } from './component-y/component-y.component';

@Component({
  selector: 'app-componentx',
  templateUrl: './componentx.component.html',
  styleUrls: ['./componentx.component.css']
})
export class ComponentxComponent implements OnInit {
  @ViewChild('appenHere', {static : false, read : ViewContainerRef}) target: ViewContainerRef;
  private componentRef: ComponentRef<any>;

  constructor(private resolver: ComponentFactoryResolver) { }

  ngOnInit(): void {
  }
  addNewComponent() {
    let childComponent = this.resolver.resolveComponentFactory(ComponentYComponent);
    this.componentRef = this.target.createComponent(childComponent); // <-- here it's throws an error!
  }  
}
